# VibeWave — Quick Start

## Backend
cd backend
npm install
npm run dev

Backend runs on http://localhost:4000

## Frontend
cd frontend
npm install
npm run dev

Frontend runs on http://localhost:5173

## Upload a song
POST http://localhost:4000/api/songs/upload (multipart/form-data)
fields: audio (file), art (file optional), title, artist, mood
