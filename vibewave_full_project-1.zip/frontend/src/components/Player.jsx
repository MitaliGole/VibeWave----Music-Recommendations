import React, {useEffect, useRef, useState} from 'react'

export default function Player({track}){
  const audioRef = useRef(null);
  const [playing, setPlaying] = useState(false);

  useEffect(()=>{
    if(track){
      if(!audioRef.current) audioRef.current = new Audio();
      audioRef.current.src = track.audio_path;
      audioRef.current.play();
      setPlaying(true);
    }
    return ()=>{ /* cleanup optional */ }
  },[track]);

  function toggle(){
    if(!audioRef.current) return;
    if(audioRef.current.paused){ audioRef.current.play(); setPlaying(true); }
    else { audioRef.current.pause(); setPlaying(false); }
  }

  return (
    <div className="player">
      <div style={{display:'flex',alignItems:'center',gap:12}}>
        <div style={{width:52,height:52,backgroundImage:`url(${track?.art_path||''})`,backgroundSize:'cover',borderRadius:8}} />
        <div>
          <div style={{fontWeight:700}}>{track?.title || 'Not playing'}</div>
          <div style={{color:'#94a3b8',fontSize:13}}>{track?.artist || ''}</div>
        </div>
      </div>
      <div style={{marginLeft:'auto'}}>
        <button className="btn" onClick={toggle}>{playing? 'Pause':'Play'}</button>
      </div>
    </div>
  )
}
