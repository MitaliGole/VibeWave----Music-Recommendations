import React from 'react'
export default function SongCard({song,onPlay}){
  return (
    <div className="card song-row">
      <div className="art" style={{backgroundImage:`url(${song.art_path || ''})`}} />
      <div style={{flex:1}}>
        <div style={{fontWeight:700}}>{song.title}</div>
        <div style={{color:'#94a3b8'}}>{song.artist} · {song.mood}</div>
      </div>
      <div>
        <button className="btn" onClick={()=> onPlay(song)}>Play</button>
      </div>
    </div>
  )
}
