import React from 'react'
export default function Header(){
  return (
    <header className="header">
      <div className="logo">
        <div style={{width:44,height:44,borderRadius:8,background:"linear-gradient(135deg,#6C63FF,#FF6584)",display:'flex',alignItems:'center',justifyContent:'center',fontWeight:800}}>VW</div>
        <div>
          <div style={{fontWeight:800}}>VibeWave</div>
          <div style={{fontSize:12,color:'#94a3b8'}}>Music for every mood</div>
        </div>
      </div>
      <nav>
        <a href="#">Home</a>
      </nav>
    </header>
  )
}
