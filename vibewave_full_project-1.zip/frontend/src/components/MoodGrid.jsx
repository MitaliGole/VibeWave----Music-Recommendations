import React from 'react'
import SongCard from './SongCard'

const moods = [
  {id:'happy',emoji:'😊',label:'Happy'},
  {id:'sad',emoji:'😭',label:'Sad'},
  {id:'chill',emoji:'🎧',label:'Chill'},
  {id:'romantic',emoji:'❤️',label:'Romantic'},
  {id:'workout',emoji:'🔥',label:'Workout'},
  {id:'travel',emoji:'🚗',label:'Travel'},
];

export default function MoodGrid({songs,onPlay}){
  return (
    <div>
      <h2>Browse by mood</h2>
      <div className="mood-grid">
        {moods.map(m=> (
          <div className="card" key={m.id}>
            <div style={{fontSize:20}}>{m.emoji}</div>
            <div style={{fontWeight:700}}>{m.label}</div>
          </div>
        ))}
      </div>

      <h2>Recommended</h2>
      <div style={{display:'grid',gap:10}}>
        {songs.map(s=> <SongCard key={s.id} song={s} onPlay={onPlay} />)}
      </div>
    </div>
  )
}
