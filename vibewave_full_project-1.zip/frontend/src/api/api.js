const BASE = import.meta.env.VITE_API_URL || 'http://localhost:4000/api';
export async function fetchSongs(){
  const res = await fetch(`${BASE}/songs`);
  if(!res.ok) throw new Error('Failed');
  return res.json();
}

export async function uploadSong(formData){
  const res = await fetch(`${BASE}/songs/upload`, { method:'POST', body: formData });
  return res.json();
}
