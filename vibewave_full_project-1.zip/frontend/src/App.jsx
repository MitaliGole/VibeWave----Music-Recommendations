import React, {useState, useEffect} from 'react'
import Header from './components/Header'
import MoodGrid from './components/MoodGrid'
import Player from './components/Player'
import { fetchSongs } from './api/api'

export default function App(){
  const [songs,setSongs] = useState([]);
  const [playing,setPlaying] = useState(null);

  useEffect(()=>{
    (async()=>{
      try{
        const res = await fetchSongs();
        setSongs(res);
      }catch(e){
        console.error(e);
      }
    })();
  },[]);

  return (
    <div className="app">
      <div className="container">
        <Header />
        <main>
          <h1 className="title">Find the perfect song for every mood</h1>
          <MoodGrid songs={songs} onPlay={(s)=>setPlaying(s)} />
        </main>
      </div>
      <Player track={playing} />
    </div>
  )
}
