const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const SECRET = process.env.JWT_SECRET || 'replace_with_secure_secret';

module.exports = (db) => {
  const router = express.Router();

  router.post('/register', async (req,res)=>{
    try{
      const {email,password,name} = req.body;
      if(!email || !password) return res.status(400).json({error:'Email and password required'});
      const hash = await bcrypt.hash(password, 10);
      const stmt = db.prepare('INSERT INTO users (email,password_hash,name) VALUES (?,?,?)');
      const info = stmt.run(email, hash, name || '');
      const user = db.prepare('SELECT id,email,name FROM users WHERE id=?').get(info.lastInsertRowid);
      const token = jwt.sign({id:user.id,email:user.email}, SECRET, {expiresIn:'7d'});
      res.json({token, user});
    }catch(e){
      console.error(e);
      res.status(400).json({error: 'Could not register (maybe user exists)'});
    }
  });

  router.post('/login', async (req,res)=>{
    try{
      const {email,password} = req.body;
      const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);
      if(!user) return res.status(400).json({error:'Invalid credentials'});
      const ok = await bcrypt.compare(password, user.password_hash);
      if(!ok) return res.status(400).json({error:'Invalid credentials'});
      const token = jwt.sign({id:user.id,email:user.email}, SECRET, {expiresIn:'7d'});
      res.json({token, user:{id:user.id,email:user.email,name:user.name}});
    }catch(e){
      console.error(e);
      res.status(500).json({error:'Server error'});
    }
  });

  router.get('/me', (req,res)=>{
    const auth = req.headers.authorization;
    if(!auth) return res.status(401).json({error:'No token'});
    const token = auth.replace('Bearer ','');
    try{
      const data = jwt.verify(token, SECRET);
      const user = db.prepare('SELECT id,email,name FROM users WHERE id=?').get(data.id);
      res.json({user});
    }catch(e){
      res.status(401).json({error:'Invalid token'});
    }
  });

  return router;
};
