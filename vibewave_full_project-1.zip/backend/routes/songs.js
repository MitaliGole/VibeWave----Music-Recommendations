const express = require('express');
const path = require('path');

module.exports = (db, upload) => {
  const router = express.Router();

  // upload audio + optional art
  router.post('/upload', upload.fields([{name:'audio',maxCount:1},{name:'art',maxCount:1}]), (req,res)=>{
    try{
      const {title,artist,mood} = req.body;
      const audio = req.files['audio'] && req.files['audio'][0];
      const art = req.files['art'] && req.files['art'][0];
      if(!audio) return res.status(400).json({error:'audio required'});
      const audio_path = `/uploads/${path.basename(audio.path)}`;
      const art_path = art ? `/uploads/${path.basename(art.path)}` : '';
      const info = db.prepare('INSERT INTO songs (title,artist,mood,art_path,audio_path) VALUES (?,?,?,?,?)')
        .run(title, artist, mood, art_path, audio_path);
      const song = db.prepare('SELECT * FROM songs WHERE id=?').get(info.lastInsertRowid);
      res.json(song);
    }catch(e){
      console.error(e);
      res.status(500).json({error:'upload failed'});
    }
  });

  // list songs
  router.get('/', (req,res)=>{
    const {mood, q} = req.query;
    let sql = 'SELECT * FROM songs';
    const params = [];
    if(mood || q){
      const parts = [];
      if(mood){ parts.push('mood = ?'); params.push(mood); }
      if(q){ parts.push('(title LIKE ? OR artist LIKE ?)'); params.push(`%${q}%`, `%${q}%`); }
      sql += ' WHERE ' + parts.join(' AND ');
    }
    sql += ' ORDER BY id DESC';
    const rows = db.prepare(sql).all(...params);
    res.json(rows);
  });

  return router;
};
