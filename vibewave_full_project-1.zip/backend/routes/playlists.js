const express = require('express');
module.exports = (db) => {
  const router = express.Router();

  // create playlist
  router.post('/', (req,res)=>{
    const {user_id, title, description} = req.body;
    const info = db.prepare('INSERT INTO playlists (user_id,title,description) VALUES(?,?,?)').run(user_id,title,description);
    res.json({id: info.lastInsertRowid, title, description});
  });

  // add song to playlist
  router.post('/:id/add', (req,res)=>{
    const playlist_id = req.params.id;
    const {song_id} = req.body;
    db.prepare('INSERT OR IGNORE INTO playlist_songs (playlist_id,song_id) VALUES(?,?)').run(playlist_id,song_id);
    res.json({ok:true});
  });

  // get songs in playlist
  router.get('/:id', (req,res)=>{
    const id = req.params.id;
    const songs = db.prepare(`SELECT s.* FROM songs s
      JOIN playlist_songs ps ON ps.song_id = s.id
      WHERE ps.playlist_id = ?`).all(id);
    res.json({id, songs});
  });

  return router;
};
