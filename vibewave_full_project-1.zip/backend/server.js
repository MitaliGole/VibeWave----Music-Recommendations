const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const app = express();
app.use(cors());
app.use(express.json());

const UPLOAD_DIR = path.join(__dirname, 'uploads');
if(!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR);
const upload = multer({ dest: UPLOAD_DIR });
app.use('/uploads', express.static(UPLOAD_DIR));

// init DB
const dbPath = path.join(__dirname, 'db.sqlite3');
const db = new Database(dbPath);
const migrationSql = fs.readFileSync(path.join(__dirname,'migrations.sql'),'utf8');
db.exec(migrationSql);

// mount routes
app.use('/api/auth', require('./routes/auth')(db));
app.use('/api/songs', require('./routes/songs')(db, upload));
app.use('/api/playlists', require('./routes/playlists')(db));

// health
app.get('/api/health', (req,res)=> res.json({ok:true}));

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log(`VibeWave backend running on ${PORT}`));
